const CONSTANTS = {
	MODULE_NAME: "scene-transitions",
	PATH: `modules/scene-transitions/`,
};

CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;

export default CONSTANTS;
